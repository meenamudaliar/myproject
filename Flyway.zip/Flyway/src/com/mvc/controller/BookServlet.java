package com.mvc.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.FlightBean;

import com.mvc.dao.FlightDao;

/**
 * Servlet implementation class BookServlet
 */
@WebServlet("/BookServlet")
public class BookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();  
        out.println("<h1>Passenger Details</h1>");  
        String fid=request.getParameter("id");  
        int id=Integer.parseInt(fid);  
         
       FlightBean fb=FlightDao.getFlightsById(id);  
          
        out.print("<form action='PaymentServlet' method='post'>");  
        out.print("<table>");  
        out.print("<tr><td>Flight no:</td><td><input type='text' name='id' value='"+fb.getFlightno()+"'/></td></tr>");  
        out.print("<tr><td>Passenger Name</td><td><input type='text' pname='pname'/></td></tr>");  
        out.print("<tr><td>Address</td><td><input type='text' name='add' /></td></tr>"); 
       
        out.print("<tr><td>Email</td><td><input type='text' name='email' /></td></tr>"); 
        out.print("<tr><td>Phone</td><td><input type='text' name='phone' /></td></tr>"); 
        out.print("<tr><td>Date</td><td><input type='text' name='date' value='"+fb.getDate()+"'/></td></tr>");  
        out.print("<tr><td>Time</td><td><input type='text' name='time' value='"+fb.getDeparturetime()+"'/></td></tr>");  
        out.print("<tr><td>Price</td><td><input type='text' name='price' value='"+fb.getPrice()+"'/></td></tr>");  
        out.print("<tr><td colspan='2'><input type='submit' value='Submit '/></td></tr>");  
        out.print("</table>");  
        out.print("</form>");  
          
        out.close();  
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

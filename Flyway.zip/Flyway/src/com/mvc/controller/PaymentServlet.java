package com.mvc.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.FlightBean;

import com.mvc.dao.FlightDao;

/**
 * Servlet implementation class PaymentServlet
 */
@WebServlet("/PaymentServlet")
public class PaymentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PaymentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();  
        out.println("<h1>payment Details</h1>");  
                       
        out.print("<form action='Success.jsp' method='post'>");  
        out.print("<table>");  
        out.print("<tr><td>Card no</td><td><input type='text' name='cardno' /></td></tr>");  
        out.print("<tr><td>Card Holder Name</td><td><input type='text' name='cname'/></td></tr>");  
        out.print("<tr><td>Expiry:Month</td><td><input type='text' name='month' /></td><td>Year</td><td><input type='text' name='year' /></td></tr>"); 
       
        out.print("<tr><td>cvv</td><td><input type='text' name='cvv' /></td></tr>"); 
       
        out.print("<tr><td colspan='2'><input type='submit' value='Pay '/></td></tr>");  
        out.print("</table>");  
        out.print("</form>");  
        
          
        out.close();  
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();  
        out.println("<h1>Payment Details</h1>");  
       
        
        String fid=request.getParameter("id");  
        int id=Integer.parseInt(fid);  
        
          
        FlightBean fb=new FlightBean();  
        fb.setFlightno(id);  
        int status=FlightDao.update(id);  
        if(status>0){  
                       
                
        out.print("<form action='Success.jsp' method='post'>");  
        out.print("<table>");  
        out.print("<tr><td>Card no</td><td><input type='text' name='cardno' /></td></tr>");  
        out.print("<tr><td>Card Holder Name</td><td><input type='text' name='cname'/></td></tr>");  
        out.print("<tr><td>Expiry:Month<td><input type='text' name='month' /></td><td>Year</td><td><input type='text' name='year' /></td></tr>"); 
       
        out.print("<tr><td>cvv</td><td><input type='text' name='cvv' /></td></tr>"); 
        
       
        out.print("<tr><td colspan='2'><input type='submit' value='Pay '/></td></tr>");  
        out.print("</table>");  
        out.print("</form>"); 
        }
        else{  
            out.println("Sorry! unable to book");  
        }   
        out.close();  
	}

}

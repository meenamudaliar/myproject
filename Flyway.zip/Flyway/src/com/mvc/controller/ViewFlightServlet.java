package com.mvc.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.FlightBean;

import com.mvc.dao.FlightDao;


/**
 * Servlet implementation class ViewFlightServlet
 */
@WebServlet("/ViewFlightServlet")
public class ViewFlightServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewFlightServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		 out.println("<h1>Flight List</h1>");
		 response.setContentType("text/html"); 
		 String src=request.getParameter("source");
		 String dst=request.getParameter("dstn");
         
	        List<FlightBean> list=FlightDao.getAllFlights(src, dst);  
	          
	        out.print("<table border='1' width='100%'");  
	        out.print("<tr><th>Flight No</th><th>Flight name</th><th>source</th><th>destination</th><th>Date</th><th>DepartureTime</th><th>ArrivalTime</th><th>price</th><th>seats</th><th>Book</th></tr>");  
	        for(FlightBean fb:list){  
	         out.print("<tr><td>"+fb.getFlightno()+"</td><td>"+fb.getFlightname()+"</td><td>"+fb.getSource()+"</td><td>"+fb.getDestination()+"</td><td>"+fb.getDate()+"</td><td>"+fb.getDeparturetime()+"</td><td>"+fb.getArraivaltime()+"</td><td>"+fb.getPrice()+"</td><td>"+fb.getSeats()+"</td><td><a href='BookServlet?id="+fb.getFlightno()+"'>Book</a></td></tr>");  
	        }  
	        out.print("</table>");  
	          
	        out.close();  

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

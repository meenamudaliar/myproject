package com.mvc.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.bean.FlightBean;

import com.mvc.dao.FlightDao;


/**
 * Servlet implementation class AdminServlet
 */
@WebServlet("/AdminServlet")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
PrintWriter out=response.getWriter();  
       String fno=request.getParameter("no");
        int flino=Integer.parseInt(fno);
        
        String fname=request.getParameter("name");  
        String source=request.getParameter("src");  
        String desti=request.getParameter("dstn");  
        String date=request.getParameter("date");
        String artime=request.getParameter("AT");
        String Deptime=request.getParameter("DT");
        String pric=request.getParameter("price");
        int price=Integer.parseInt(pric);
       String set=request.getParameter("seat");
        int seat=Integer.parseInt(set);
        FlightBean fb=new FlightBean();  
        fb.setFlightno(flino);  
        fb.setFlightname(fname);  
        fb.setSource(source);  
        fb.setDestination(desti);  
        fb.setDate(date); 
        fb.setDeparturetime(artime);
        fb.setArraivaltime(Deptime);
        fb.setPrice(price);
        fb.setSeats(seat);
        int status=FlightDao.save(fb);  
        if(status>0){  
            out.print("<p>Record saved successfully!</p>");  
            request.getRequestDispatcher("AdminRegister.jsp").include(request, response);
        }else{  
            out.println("Sorry! unable to save record");  
        }  

		doGet(request, response);
	}


}

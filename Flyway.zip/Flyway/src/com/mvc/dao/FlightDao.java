package com.mvc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mvc.bean.FlightBean;

import com.mvc.util.DBConnection;

public class FlightDao {
	 public static int save(FlightBean fb)
     {
    	int status=0;
    	
    	int fid = fb.getFlightno(); 
        String fname = fb.getFlightname();
        String src = fb. getSource(); 
        String dst = fb.getDestination();
        String date=fb.getDate();
        String deptime=fb.getDeparturetime();
        String arrtime=fb. getArraivaltime();
        int price=fb.getPrice();
        int seats=fb.getSeats();
        Connection con = null;
        Statement statement = null;
        
        try
        {
            con = DBConnection.createConnection(); 
            statement = con.createStatement(); 
            status = statement.executeUpdate("insert into flight(Fid,Fname,source,destn,date,deptime,arrtime,price,seats)values('"+fid+"','"+fname+"','"+ src+"','"+dst+"','"+date+"','"+deptime+"','"+arrtime+"','"+price+"','"+seats+"')"); 
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return status;  
    }  
	 public static FlightBean getFlightsById(int id){  
	        FlightBean fb=new FlightBean();  
	        Connection con = null;
	        try{  
	        	con=DBConnection.createConnection(); 
	            PreparedStatement ps=con.prepareStatement("select * from flight where Fid=?");  
	            ps.setInt(1,id);  
	            ResultSet rs=ps.executeQuery();  
	            if(rs.next()){  
	                fb.setFlightno(rs.getInt(1));  
	                fb.setFlightname(rs.getString(2));  
	                fb.setSource(rs.getString(3));  
	                fb.setDestination(rs.getString(4));  
	                fb.setDate(rs.getString(5)); 
	                fb.setDeparturetime(rs.getString(6));
	                fb.setArraivaltime(rs.getString(7));
	                fb.setPrice(rs.getInt(8));
	                fb.setSeats(rs.getInt(9));
	            }  
	            con.close();  
	        }catch(Exception ex){ex.printStackTrace();}  
	          
	        return fb;  
	    }  
	 public static List<FlightBean> getAllFlights(String src,String dst){  
	        FlightBean fb=new FlightBean();  
	        List<FlightBean> list=new ArrayList<FlightBean>(); 
	        Connection con = null;
	        try{  
	        	con=DBConnection.createConnection(); 
	            PreparedStatement ps=con.prepareStatement("select * from flight where source=? and destn=? and seats>0");  
	            ps.setString(1,src); 
	            ps.setString(2, dst);
	            ResultSet rs=ps.executeQuery();  
	           if(rs.next()){  
	            	fb.setFlightno(rs.getInt(1));  
	                fb.setFlightname(rs.getString(2));  
	                fb.setSource(rs.getString(3));  
	                fb.setDestination(rs.getString(4));  
	                fb.setDate(rs.getString(5)); 
	                fb.setDeparturetime(rs.getString(6));
	                fb.setArraivaltime(rs.getString(7));
	                fb.setPrice(rs.getInt(8));
	                fb.setSeats(rs.getInt(9));
	                list.add(fb);
	            }  
	            con.close();  
	        }catch(Exception ex){ex.printStackTrace();}  
	          
	        return list;  
	    }  
	 public static int update(int id){  
	        FlightBean fb=new FlightBean();  
	        Connection con = null;
	        int status=0;
	        
	        try{  
	        	con=DBConnection.createConnection(); 
	            PreparedStatement ps=con.prepareStatement("update flight set seats=seats-1 where Fid=?");  
	            ps.setInt(1,id);  
	            status=ps.executeUpdate(); 
	           con.close();  
	        }catch(Exception ex){ex.printStackTrace();}  
	          
	        return status;  
	    }  
}

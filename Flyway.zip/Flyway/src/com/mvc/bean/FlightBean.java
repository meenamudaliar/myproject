package com.mvc.bean;

public class FlightBean {
private int Flightno;
private String flightname;
private String source;
private String destination;
private String date;
private String departuretime;
private String arraivaltime;

public int getFlightno() {
	return Flightno;
}
public void setFlightno(int flightno) {
	Flightno = flightno;
}
public String getFlightname() {
	return flightname;
}
public void setFlightname(String flightname) {
	this.flightname = flightname;
}
public String getSource() {
	return source;
}
public void setSource(String source) {
	this.source = source;
}
public String getDestination() {
	return destination;
}
public void setDestination(String destination) {
	this.destination = destination;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public String getDeparturetime() {
	return departuretime;
}
public void setDeparturetime(String departuretime) {
	this.departuretime = departuretime;
}
public String getArraivaltime() {
	return arraivaltime;
}
public void setArraivaltime(String arraivaltime) {
	this.arraivaltime = arraivaltime;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public int getSeats() {
	return seats;
}
public void setSeats(int seats) {
	this.seats = seats;
}
private int price;
private int seats;

}

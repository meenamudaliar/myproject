package net.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import net.entity.User;
import net.repository.UserRepository;
import net.servicce.UserService;

@Controller
public class UserController {

	@Autowired
	private UserRepository userRepo;
	@Autowired
	private UserService uservice;
	
	
	@GetMapping("/register")
	public String showRegistrationForm(Model model) {
		model.addAttribute("user", new User());
		
		return "signup_form";
	}
	
	@PostMapping("/process_register")
	public String processRegister(User user) {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword = passwordEncoder.encode(user.getPassword());
		user.setPassword(encodedPassword);
		
		userRepo.save(user);
		
		return "register_success";
	}
	
	@GetMapping("/users")
	public String listUsers(Model model, @Param("keyword") String keyword) {
		List<User> listUsers = uservice.listAll(keyword);
		
		model.addAttribute("listUsers", listUsers);
		model.addAttribute("keyword", keyword);
		
		return "users";
	}
	@GetMapping("/change")
	public String showChangeForm(Model model) {
		model.addAttribute("user", new User());
		
		return "changepass";
	}
	
	@RequestMapping("/change/{username}")
	public ModelAndView showEditProductForm(@PathVariable(name = "username") String username) {
		ModelAndView mav = new ModelAndView("changepass");
		
		User user = uservice.getUser(username);
		mav.addObject("user", user);
		
		return mav;
	}	
	@PostMapping("/process_change")
	public String processchange(User user) {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword = passwordEncoder.encode(user.getPassword());
		user.setPassword(encodedPassword);
		String username=user.getUsername();
		String password=user.getPassword();
		uservice.updateUser(password,username);
		
		return "change_success";
	}

}



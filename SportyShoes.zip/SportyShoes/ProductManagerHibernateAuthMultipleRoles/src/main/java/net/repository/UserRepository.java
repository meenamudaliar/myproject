package net.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import net.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

	@Query("SELECT u FROM User u WHERE u.username = ?1")
	public User findByUsername(String username);
    
	@Query("SELECT u FROM User u WHERE CONCAT(u.username) LIKE %?1%")
	public List<User> search(String keyword);
	@Modifying
	@Query("UPDATE User u SET u.password=:password WHERE u.username=:username")

	public void Update(String password, String username);

	
	
		
}

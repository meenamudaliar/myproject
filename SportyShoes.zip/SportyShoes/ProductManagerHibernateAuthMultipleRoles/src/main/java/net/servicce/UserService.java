package net.servicce;

import java.util.List;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import net.entity.User;
import net.repository.UserRepository;

@Service
@Transactional
public class UserService {
	@Autowired
	private UserRepository repository;
	@Autowired
	EntityManager em;
	
	public List<User> listAll(String keyword) {
		if (keyword != null) {
		return repository.search(keyword);
	}
	return repository.findAll();
	}
	public void updateUser(String password,String username) {
		repository.Update(password,username);
	}
	
	public void save(User user) {
		repository.save(user);
	}
	public User update(User user) {
		em.merge(user);
		return user;
	}
	
	public User get(Long id) {
		return em.find(User.class,id);
	}
	public User getUser(String username) {
		return repository.findByUsername(username);
	}
	
	public void delete(Long id) {
		repository.deleteById(id);
	}
	
	
     
   


}
